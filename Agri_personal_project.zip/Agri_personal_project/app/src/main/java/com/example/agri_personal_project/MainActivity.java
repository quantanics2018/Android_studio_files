package com.example.agri_personal_project;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.inappmessaging.model.Button;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        EditText subscribe_input;
        View click_btn;

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        subscribe_input = findViewById(R.id.topic_input);
        click_btn =  findViewById(R.id.subcribe_btn);


        click_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String topic_name = subscribe_input.getText().toString();

                Toast.makeText(MainActivity.this, "your topic"+topic_name, Toast.LENGTH_SHORT).show();
                Intent second = new Intent(MainActivity.this, SecondActivity.class);
                second.putExtra("subscribe_topic",topic_name);
                startActivity(second);
            }
        });
    }
}