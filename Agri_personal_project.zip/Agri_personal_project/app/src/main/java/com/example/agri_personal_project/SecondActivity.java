package com.example.agri_personal_project;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONException;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONObject;

public class SecondActivity extends AppCompatActivity {
    TextView rain_dropv,soil_moisturev,relay_conditionv,water_bumpv;
    MqttClient client;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.second_activity);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.second), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        rain_dropv = findViewById(R.id.rain_drop_sensor_val);
        soil_moisturev = findViewById(R.id.soil_moisture_sensor_val);
        relay_conditionv = findViewById(R.id.relay_condition_val);
        water_bumpv = findViewById(R.id.water_bump_val);


        Intent intent = getIntent();
        String topic_name = intent.getStringExtra("subscribe_topic").toString();


        Toast.makeText(getBaseContext(), "your subcription topic is:"+topic_name, Toast.LENGTH_SHORT).show();
//        rain_dropv.setText(topic_name);


        if(!isConnected(SecondActivity.this)){
            Toast.makeText(this,"Please connect to the internet", Toast.LENGTH_LONG).show();
        }else{
            try {
                client = new MqttClient("tcp://quantanics.in:1883", MqttClient.generateClientId(), new MemoryPersistence());
            } catch (MqttException e) {
                Toast.makeText(getApplicationContext(), "unable to set up client", Toast.LENGTH_SHORT).show();
            }

            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName("quantanics");
            options.setPassword("quantanics123".toCharArray());

            try {
                client.connect(options);
                client.subscribe(topic_name,0);
                Toast.makeText(getApplicationContext(), "connected", Toast.LENGTH_SHORT).show();
            } catch (MqttException e) {
                Log.e("error", String.valueOf(e));
                Toast.makeText(getApplicationContext(), "unable to connect", Toast.LENGTH_SHORT).show();
            }
        }

        client.setCallback(new MqttCallback() {
                               @Override
                               public void connectionLost(Throwable cause) {
                                   Toast.makeText(getApplicationContext(), "connection lost", Toast.LENGTH_SHORT).show();

                               }

                               @SuppressLint("SetTextI18n")
                               @Override
                               public void messageArrived(String topic, MqttMessage message) throws JSONException {
                                   String string_json_val = new String(message.getPayload());
                                   handle_json(string_json_val);
                               }

                               @Override
                               public void deliveryComplete(IMqttDeliveryToken token) {
                                   //no need
                               }
                           }
        );


    }

    private void handle_json(String payload_msg){
        try {
            JSONObject  json_obj = new JSONObject(payload_msg);
            String soil_moisture_val = json_obj.getString("soil_moisture");
            String rain_drop_val = json_obj.getString("raindrop_sensor");
            String relay_condition_val = json_obj.getString("relay_condition");
            runOnUiThread(()->{
                    soil_moisturev.setText(soil_moisture_val+"%");
                    if(rain_drop_val.toString()=="1"){
                        rain_dropv.setText("True");
                    }else if(rain_drop_val.toString()=="0"){
                        rain_dropv.setText("False");
                    }

                    relay_conditionv.setText(relay_condition_val);
                    if(relay_condition_val.toString().toLowerCase()=="true"){
                        water_bumpv.setText("ON");
                    }else{
                        water_bumpv.setText("OFF");
                    }
            });





        }
        catch (JSONException e){
            e.printStackTrace();
        }
    }

    private boolean isConnected(SecondActivity mainActivity) {
        ConnectivityManager connectivityManager=(ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mobile_data = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return (wifi != null && wifi.isConnected()) || (mobile_data != null && mobile_data.isConnected());
    }
}
