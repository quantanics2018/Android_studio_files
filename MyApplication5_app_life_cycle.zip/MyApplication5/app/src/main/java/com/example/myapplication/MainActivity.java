package com.example.myapplication;

import android.os.Bundle;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    protected WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate called");
        Toast.makeText(this, "onCreate called", Toast.LENGTH_SHORT).show();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        webView = findViewById(R.id.webview1);
        // enables javascript
        WebSettings websettings = webView.getSettings();
        websettings.setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());


        // load url
        webView.loadUrl("https://www.google.com");



    }

    @Override
    protected void onStart(){
        super.onStart();
        Log.d(TAG,"onStart called");
        Toast.makeText(this,"onStart called",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d(TAG,"onResume is called");
        Toast.makeText(this,"onResume is called",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d(TAG,"OnPause is called");
        Toast.makeText(this,"onPause is called",Toast.LENGTH_LONG).show();

    }

    @Override
    protected  void onStop(){
        super.onStop();
        Log.d(TAG,"onStop is called");
        Toast.makeText(this,"onStop is called",Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onRestart(){
        super.onRestart();
        Log.d(TAG,"onRestart is called");
        Toast.makeText(this,"onRestart is called",Toast.LENGTH_LONG).show();

    }

    @Override
    protected void  onDestroy(){
        super.onDestroy();
        Log.d(TAG,"onDestroy is called");
        Toast.makeText(this,"onDestroy is called ",Toast.LENGTH_LONG).show();
    }
}