package com.example.mqttreceiver;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    MqttClient client;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView textView = findViewById(R.id.data);
        TextView topic = (TextView) findViewById(R.id.topic);

        if(!isConnected(MainActivity.this)){
            Toast.makeText(this,"Please connect to the internet", Toast.LENGTH_LONG).show();
        }else{
            try {
                client = new MqttClient("tcp://quantanics.in:1883", MqttClient.generateClientId(), new MemoryPersistence());
            } catch (MqttException e) {
                Toast.makeText(getApplicationContext(), "unable to set up client", Toast.LENGTH_SHORT).show();
            }

            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName("quantanics");
            options.setPassword("quantanics123".toCharArray());

            try {
                client.connect(options);
                Toast.makeText(getApplicationContext(), "connected", Toast.LENGTH_SHORT).show();
            } catch (MqttException e) {
                Log.e("error", String.valueOf(e));
                Toast.makeText(getApplicationContext(), "unable to connect", Toast.LENGTH_SHORT).show();
            }
        }

        client.setCallback(new MqttCallback() {
                               @Override
                               public void connectionLost(Throwable cause) {
                                   Toast.makeText(getApplicationContext(), "connection lost", Toast.LENGTH_SHORT).show();

                               }

                               @SuppressLint("SetTextI18n")
                               @Override
                               public void messageArrived(String topic, MqttMessage message) throws JSONException {
                                   textView.append("Message from topic: "+topic+" : " + message);
                               }

                               @Override
                               public void deliveryComplete(IMqttDeliveryToken token) {
                                   //no need
                               }
                           }
        );

        findViewById(R.id.subscribe).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if(client.isConnected()){
                        client.subscribe(topic.getText().toString(), 2);
                        Toast.makeText(getApplicationContext(), "Listening for messages", Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(getApplicationContext(), "Client is not connected", Toast.LENGTH_LONG).show();
                    }
                } catch (MqttException e) {
                    Toast.makeText(getApplicationContext(), "unable to Subscribe", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }


    private boolean isConnected(MainActivity mainActivity) {
        ConnectivityManager connectivityManager=(ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mobile_data = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return (wifi != null && wifi.isConnected()) || (mobile_data != null && mobile_data.isConnected());
    }
}