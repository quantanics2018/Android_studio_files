package com.example.firebase_connection;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    private EditText username,password,email;
    private Button btn;
    private DatabaseReference databaseReference;
    @SuppressLint("missingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        email = findViewById(R.id.email);
        btn  = findViewById(R.id.btn);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        databaseReference = database.getReference("firebasedemo");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String username_txt = username.getText().toString();
                String password_txt = password.getText().toString();
                String email_txt = email.getText().toString();

                // Create a User object
                User user = new User(username_txt,password_txt,email_txt);
                databaseReference.push().setValue(user);


                // clear input fields
                username.setText("");
                password.setText("");
                email.setText("");


                Toast.makeText(MainActivity.this, "Firebase Data inserted..."+username_txt, Toast.LENGTH_SHORT).show();
            }
        });

    }
}