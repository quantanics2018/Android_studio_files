
package com.example.distancemeasure;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.json.JSONException;
import org.json.JSONObject;

public class DistanceCall extends AppCompatActivity {

    private static final String TAG = DistanceCall.class.getSimpleName();

    private TextView distanceText;
    private MqttClient client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance_call);

        distanceText = findViewById(R.id.distanceText);

        String topic = getIntent().getStringExtra("measure");
        Log.d(TAG, "Subscribing to topic: " + topic);
        subscribeToMqtt(topic);
    }

    private void subscribeToMqtt(String topic) {
        try {
            String broker = "tcp://quantanics.in:1883";
            String clientId = MqttClient.generateClientId();
            client = new MqttClient(broker, clientId, null);

            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);

            // Set username and password
            options.setUserName("quantanics");
            options.setPassword("quantanics123".toCharArray());


            client.connect(options);
            Log.d(TAG, "Connected to MQTT broker");
            Toast.makeText(DistanceCall.this, "Connected to MQTT broker", Toast.LENGTH_SHORT).show();
            client.subscribe(topic);
            Log.d(TAG, "Subscribed to topic: " + topic);

            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    Log.d(TAG, "Connection lost: " + cause.getMessage());
                    showToast("Connection lost: " + cause.getMessage());
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    String msg = new String(message.getPayload());
                    Log.d(TAG, "Message received: " + msg);
                    handleJsonMessage(msg);
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    // Handle message delivery completion, if needed
                }
            });
        } catch (MqttException e) {
            Log.e(TAG, "Error connecting to MQTT broker", e);
            showToast("Error connecting to MQTT broker: " + e.getMessage());
        }
    }

    private void handleJsonMessage(String message) {
        try {
            JSONObject jsonObject = new JSONObject(message);
            final String distance = jsonObject.getString("distance");

            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    distanceText.setText("Distance: " + distance + " cm");
                }
            });

            showToast("Message received: " + distance);
        } catch (JSONException e) {
            Log.e(TAG, "Error parsing JSON message", e);
            showToast("Error parsing JSON message: " + e.getMessage());
        }
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(DistanceCall.this, message, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            if (client != null && client.isConnected()) {
                client.disconnect();
            }
        } catch (MqttException e) {
            Log.e(TAG, "Error disconnecting from MQTT broker", e);
        }
    }
}
