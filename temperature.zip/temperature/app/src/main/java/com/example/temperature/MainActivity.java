package com.example.temperature;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

@SuppressLint("MissingInflatedId")
public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText inputText = findViewById(R.id.stopic);
        Button subscribeButton = findViewById(R.id.subscribeButton);

        subscribeButton.setOnClickListener(v -> {
            String topic = inputText.getText().toString();
            if (topic.isEmpty()) {
                Toast.makeText(MainActivity.this, "Please enter a topic", Toast.LENGTH_SHORT).show();
                return;
            }else{
                Intent intent = new Intent(MainActivity.this,SecondActivity.class);
                //Toast.makeText(getBaseContext(),"sub topic"+topic,Toast.LENGTH_LONG).show();
                intent.putExtra("Subscribe_topic",topic);
                startActivity(intent);
            }



        });
    }


}

