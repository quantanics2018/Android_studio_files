
/*package com.example.temperature;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

public class SecondActivity extends AppCompatActivity {
    private TextView distance1, distance2, temperature, humidity, ldrvalue, raindropval;
    MqttClient client;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.second);


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.sec), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;

        });



        Intent intent = getIntent();
        String topic_name = intent.getStringExtra("Subscribe_topic").toString();
        Toast.makeText(getBaseContext(), "your topic name is\t" + topic_name, Toast.LENGTH_LONG).show();
        if (!isConnected(SecondActivity.this)) {
            Toast.makeText(this, "Please connect to the internet", Toast.LENGTH_LONG).show();
        } else {
            try {
                client = new MqttClient("tcp://quantanics.in:1883", MqttClient.generateClientId(), new MemoryPersistence());
            } catch (MqttException e) {
                Toast.makeText(getApplicationContext(), "unable to set up client", Toast.LENGTH_SHORT).show();
            }

            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName("quantanics");
            options.setPassword("quantanics123".toCharArray());

            try {
                client.connect(options);
                client.subscribe(topic_name, 0);
                Toast.makeText(getApplicationContext(), "connected", Toast.LENGTH_SHORT).show();
            } catch (MqttException e) {
                Log.e("error", String.valueOf(e));
                Toast.makeText(getApplicationContext(), "unable to connect", Toast.LENGTH_SHORT).show();
            }
        }

        client.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {
                Toast.makeText(getApplicationContext(), "connection lost", Toast.LENGTH_SHORT).show();

            }
            

            @SuppressLint("SetTextI18n")
            @Override
            public void messageArrived(String topic, MqttMessage message) throws JSONException {
                String string_json_val = new String(message.getPayload());
                handle_json(string_json_val);
            }


            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                //no need
                Toast.makeText(getApplicationContext(), "Message published successfully", Toast.LENGTH_SHORT).show();


            }
        });
    }


    private void handle_json(String payload_msg) {
        try {
            JSONObject json_obj = new JSONObject(payload_msg);
            String distance1value = json_obj.getString("Distance1");
            String distance2value = json_obj.getString("Distance2");
            String temperaturevalue = json_obj.getString("Temperature");
            String  humidityvalue= json_obj.getString("Humidity");
            String ldrvaluevalue = json_obj.getString("ldrValue");
            String raindropvalue = json_obj.getString("rain_drop_val");
            distance1.setText(distance1value);
            distance2.setText(distance2value);
            temperature.setText(temperaturevalue);
            humidity.setText(humidityvalue);
            ldrvalue.setText(ldrvaluevalue);
            raindropval.setText(raindropvalue);


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private boolean isConnected(SecondActivity mainActivity) {
        ConnectivityManager connectivityManager = (ConnectivityManager) getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mobile_data = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return (wifi != null && ((NetworkInfo) wifi).isConnected()) || (mobile_data != null && mobile_data.isConnected());
    }
}*/

package com.example.temperature;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

public class SecondActivity extends AppCompatActivity {
    private TextView distance1, distance2, temperature, humidity, ldrvalue, raindropval;
    private MqttClient client;

    @SuppressLint({"MissingInflatedId", "SetTextI18n"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.second);

        // Initialize TextViews
        distance1 = findViewById(R.id.distance1);
        distance2 = findViewById(R.id.distance2);
        temperature = findViewById(R.id.temperature);
        humidity = findViewById(R.id.humidity);
        ldrvalue = findViewById(R.id.ldrValue);
        raindropval = findViewById(R.id.rain_drop_val);

        // Adjust padding for system bars
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.sec), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Get MQTT topic from intent
        Intent intent = getIntent();
        String topicName = intent.getStringExtra("Subscribe_topic");

        // Show topic name in toast
        Toast.makeText(this, "Subscribed to topic: " + topicName, Toast.LENGTH_SHORT).show();

        // Check internet connectivity
        if (!isConnected()) {
            Toast.makeText(this, "Please connect to the internet", Toast.LENGTH_LONG).show();
        } else {
            // MQTT connection setup
            try {
                client = new MqttClient("tcp://quantanics.in:1883", MqttClient.generateClientId(), new MemoryPersistence());
                MqttConnectOptions options = new MqttConnectOptions();
                options.setUserName("quantanics");
                options.setPassword("quantanics123".toCharArray());

                client.connect(options);
                client.subscribe(topicName, 0);
                Toast.makeText(getApplicationContext(), "Connected to MQTT", Toast.LENGTH_SHORT).show();

                // Set MQTT callback
                client.setCallback(new MqttCallback() {
                    @Override
                    public void connectionLost(Throwable cause) {
                        Toast.makeText(getApplicationContext(), "Connection lost", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void messageArrived(String topic, MqttMessage message) throws JSONException {
                        String payload = new String(message.getPayload());
                        handle_json(payload);
                    }

                    @Override
                    public void deliveryComplete(IMqttDeliveryToken token) {
                        // Not used in this scenario
                    }
                });

            } catch (MqttException e) {
                Toast.makeText(getApplicationContext(), "Failed to connect to MQTT", Toast.LENGTH_SHORT).show();
                Log.e("MQTT", "Exception while connecting: " + e.getMessage());
            }
        }
    }

    // Handle JSON payload from MQTT
    private void handle_json(String payload) {
        try {
            JSONObject jsonObject = new JSONObject(payload);

            // Retrieve values from JSON
            String distance1Value = jsonObject.getString("Distance1");
            String distance2Value = jsonObject.getString("Distance2");
            String temperatureValue = jsonObject.getString("Temperature");
            String humidityValue = jsonObject.getString("Humidity");
            String ldrValueValue = jsonObject.getString("ldrValue");
            String raindropValue = jsonObject.getString("rain_drop_val");

            // Format strings with names
            String distance1Text = "Distance 1: " + distance1Value;
            String distance2Text = "Distance 2: " + distance2Value;
            String temperatureText = "Temperature: " + temperatureValue;
            String humidityText = "Humidity: " + humidityValue;
            String ldrValueText = "LDR Value: " + ldrValueValue;
            String raindropText = "Rain Drop Value: " + raindropValue;

            // Update UI with formatted values
            runOnUiThread(() -> {
                distance1.setText(distance1Text);
                distance2.setText(distance2Text);
                temperature.setText(temperatureText);
                humidity.setText(humidityText);
                ldrvalue.setText(ldrValueText);
                raindropval.setText(raindropText);
            });

        } catch (JSONException e) {
            Log.e("MQTT", "Error parsing JSON: " + e.getMessage());
        }
    }

    // Check if device is connected to the internet
    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mobileData = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return (wifi != null && wifi.isConnected()) || (mobileData != null && mobileData.isConnected());
    }
}
