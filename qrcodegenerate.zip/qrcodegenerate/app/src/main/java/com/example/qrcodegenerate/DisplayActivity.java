package com.example.qrcodegenerate;


import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DisplayActivity extends AppCompatActivity {

    private TextView qrValueTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display);

        qrValueTextView = findViewById(R.id.qrValueTextView);

        String qrText = getIntent().getStringExtra("QR_TEXT");
        if (qrText != null) {
            qrValueTextView.setText(qrText);
        }
    }
}
