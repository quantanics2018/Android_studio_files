package com.example.qrcodegenerate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.graphics.Bitmap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class MainActivity extends AppCompatActivity {

    private EditText qrInput;
    private Button generateButton;
    private ImageView qrImageView;
    private Button retrieveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        qrInput = findViewById(R.id.qrInput);
        generateButton = findViewById(R.id.generateButton);
        qrImageView = findViewById(R.id.qrImageView);
        retrieveButton = findViewById(R.id.retrieveButton);

        generateButton.setOnClickListener(view -> {
            String text = qrInput.getText().toString();
            if (!text.isEmpty()) {
                BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                try {
                    Bitmap bitmap = barcodeEncoder.encodeBitmap(text, BarcodeFormat.QR_CODE, 200, 200);
                    qrImageView.setImageBitmap(bitmap);
                } catch (WriterException e) {
                    e.printStackTrace();
                }
            }
        });

        retrieveButton.setOnClickListener(view -> {
            String text = qrInput.getText().toString();
            Intent intent = new Intent(MainActivity.this, DisplayActivity.class);
            intent.putExtra("QR_TEXT", text);
            startActivity(intent);
        });
    }
}
