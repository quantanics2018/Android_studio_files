package com.example.dcmotorpr;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import org.json.JSONException;
import org.json.JSONObject;

public class control extends AppCompatActivity {

    private static final String MQTT_BROKER_URL = "tcp://quantanics.in:1883"; // Added tcp://
    private static final String MQTT_USERNAME = "quantanics";
    private static final String MQTT_PASSWORD = "quantanics123";
    private static final String TAG = "dccontrol";
    private static final String PUBLISHER_TOPIC = "control";
    private static final String SUBSCRIBER_TOPIC = "control";

    private MqttClient client;
    private Button forwardButton;
    private Button backwardButton;
    private SeekBar speedSeekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_control);

        forwardButton = findViewById(R.id.button1);
        backwardButton = findViewById(R.id.button2);
        speedSeekBar = findViewById(R.id.speedSeekBar);

        connectToMQTT();

        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int dutyCycle = speedSeekBar.getProgress();
                sendMotorCommand("FORWARD", dutyCycle);
            }
        });

        backwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int dutyCycle = speedSeekBar.getProgress();
                sendMotorCommand("BACKWARD", dutyCycle);
            }
        });
    }

    private void connectToMQTT() {
        try {
            client = new MqttClient(MQTT_BROKER_URL, MqttClient.generateClientId(), new MemoryPersistence());
            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName(MQTT_USERNAME);
            options.setPassword(MQTT_PASSWORD.toCharArray());

            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                    Log.e(TAG, "Connection lost", cause);
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) {
                    Log.d(TAG, "Message arrived: " + message.toString());
                    handleIncomingMessage(topic, message);
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    Log.d(TAG, "Delivery complete");
                }
            });

            client.connect(options);
            Toast.makeText(control.this, "MQTT is connected!", Toast.LENGTH_SHORT).show();
            subscribeToTopic(SUBSCRIBER_TOPIC);
        } catch (MqttException e) {
            e.printStackTrace();
            Toast.makeText(control.this, "Failed to connect to MQTT broker", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "Failed to connect to MQTT broker", e);
        }
    }

    private void subscribeToTopic(String topic) {
        if (client != null && client.isConnected()) {
            try {
                client.subscribe(topic);
                Toast.makeText(control.this, "Subscribed to topic: " + topic, Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Subscribed to topic: " + topic);
            } catch (MqttException e) {
                e.printStackTrace();
                Toast.makeText(control.this, "Failed to subscribe to topic: " + topic, Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to subscribe to topic: " + topic, e);
            }
        } else {
            Toast.makeText(control.this, "MQTT not connected", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "MQTT not connected");
        }
    }

    private void handleIncomingMessage(String topic, MqttMessage message) {
        try {
            JSONObject json = new JSONObject(new String(message.getPayload()));
            String direction = json.getString("direction");
            int dutyCycle = json.getInt("duty_cycle");

            // Display the received message
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(control.this, "Received command: Direction = " + direction + ", Duty Cycle = " + dutyCycle, Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "Received command: " + json.toString());
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
            Log.e(TAG, "Failed to parse incoming message", e);
        }
    }

    private void sendMotorCommand(String direction, int dutyCycle) {
        if (client != null && client.isConnected()) {
            try {
                JSONObject json = new JSONObject();
                json.put("direction", direction);
                json.put("duty_cycle", dutyCycle);

                String message = json.toString();
                client.publish(PUBLISHER_TOPIC, new MqttMessage(message.getBytes()));
                Toast.makeText(control.this, "Command sent: " + message, Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Command sent: " + message);
            } catch (JSONException | MqttException e) {
                e.printStackTrace();
                Toast.makeText(control.this, "Failed to send command", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to send command", e);
            }
        } else {
            Toast.makeText(control.this, "MQTT not connected", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "MQTT not connected");
        }
    }
}
