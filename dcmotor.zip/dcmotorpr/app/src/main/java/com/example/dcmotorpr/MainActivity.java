package com.example.dcmotorpr;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText publisherEditText;
    private EditText subscriberEditText;
    private Button submitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the views
        publisherEditText = findViewById(R.id.textbox_publisher);
        subscriberEditText = findViewById(R.id.textbox_subscriber);
        submitButton = findViewById(R.id.button_submit);

        // Set up the button click listener
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve text from EditText fields
                String publisher = publisherEditText.getText().toString();
                String subscriber = subscriberEditText.getText().toString();

                Intent intent = new Intent(MainActivity.this, control.class);
                intent.putExtra("PUBLISHER", publisher);
                intent.putExtra("SUBSCRIBER", subscriber);

                startActivity(intent);
            }
        });
    }
}
