package com.example.door1;

import android.annotation.SuppressLint;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.json.JSONException;
import org.json.JSONObject;

public class LockActivity extends AppCompatActivity {

    private ImageButton lockImageButton;
    private ImageButton lockImageButton1;
    private ImageView doorOpen;
    private ImageView doorClose;
    private MqttClient client;

    private static final String MQTT_BROKER_URL = "tcp://broker.emqx.io:1883";
    private static final String MQTT_USERNAME = "";
    private static final String MQTT_PASSWORD = "";
    private static final String TAG = "MainActivity2";
    private String publisher;
    private String subscriber;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lock);

        lockImageButton = findViewById(R.id.lockImage);
        lockImageButton1 = findViewById(R.id.lockImage1);
        doorClose = findViewById(R.id.lockdoor);
        doorOpen = findViewById(R.id.unlockdoor);
        doorClose.setVisibility(View.INVISIBLE);
        doorOpen.setVisibility(View.INVISIBLE);

        publisher = getIntent().getStringExtra("PUBLISHER");
        subscriber = getIntent().getStringExtra("SUBSCRIBER");
        connectToMQTT();

        lockImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lockDoor();
            }
        });

        lockImageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                unlockDoor();
            }
        });
    }

    private void connectToMQTT() {
        if (isConnected()) {
            try {
                client = new MqttClient(MQTT_BROKER_URL, MqttClient.generateClientId(), new MemoryPersistence());
                MqttConnectOptions options = new MqttConnectOptions();
                options.setUserName(MQTT_USERNAME);
                options.setPassword(MQTT_PASSWORD.toCharArray());

                client.setCallback(new MqttCallback() {
                    @Override
                    public void connectionLost(Throwable cause) {
                        Log.e(TAG, "Connection lost", cause);
                    }

                    @Override
                    public void messageArrived(String topic, MqttMessage message) {
                        Log.d(TAG, "Message arrived: " + message.toString());
                        handleIncomingMessage(message.toString());
                    }

                    @Override
                    public void deliveryComplete(IMqttDeliveryToken token) {
                        Log.d(TAG, "Delivery complete");
                    }
                });

                client.connect(options);
                Toast.makeText(LockActivity.this, "MQTT is connected!", Toast.LENGTH_SHORT).show();
                subscribeToTopic(subscriber);
            } catch (MqttException e) {
                e.printStackTrace();
                Toast.makeText(getBaseContext(), "Failed to create MQTT client", Toast.LENGTH_LONG).show();
                Log.e(TAG, "Failed to connect to MQTT broker", e);
            }
        } else {
            Toast.makeText(getBaseContext(), "Please check your internet connection", Toast.LENGTH_LONG).show();
            Log.e(TAG, "No internet connection");
        }
    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo wifi = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        NetworkInfo mobileData = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        return (wifi != null && wifi.isConnected()) || (mobileData != null && mobileData.isConnected());
    }

    private void lockDoor() {
        // Show lock door state
        Toast.makeText(this, "Door Locked", Toast.LENGTH_SHORT).show();
        doorClose.setVisibility(View.VISIBLE);
        doorOpen.setVisibility(View.INVISIBLE);

        if (client != null && client.isConnected()) {
            try {
                JSONObject json = new JSONObject();
                json.put("status", 1);  // 1 means door closed

                client.publish(publisher, new MqttMessage(json.toString().getBytes()));
                Toast.makeText(LockActivity.this, "Lock message published", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Lock message published");
            } catch (MqttException | JSONException e) {
                e.printStackTrace();
                Toast.makeText(LockActivity.this, "Failed to publish lock message", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to publish lock message", e);
            }
        } else {
            Toast.makeText(LockActivity.this, "MQTT not connected", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "MQTT not connected");
        }
    }

    private void unlockDoor() {
        // Show unlock door state
        Toast.makeText(this, "Door Unlocked", Toast.LENGTH_SHORT).show();
        doorOpen.setVisibility(View.VISIBLE);
        doorClose.setVisibility(View.INVISIBLE);

        if (client != null && client.isConnected()) {
            try {
                JSONObject json = new JSONObject();
                json.put("status", 0);  // 0 means door open

                client.publish(publisher, new MqttMessage(json.toString().getBytes()));
                Toast.makeText(LockActivity.this, "Unlock message published", Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Unlock message published");
            } catch (MqttException | JSONException e) {
                e.printStackTrace();
                Toast.makeText(LockActivity.this, "Failed to publish unlock message", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to publish unlock message", e);
            }
        } else {
            Toast.makeText(LockActivity.this, "MQTT not connected", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "MQTT not connected");
        }
    }

    private void subscribeToTopic(String subscriber) {
        if (client != null && client.isConnected()) {
            try {
                client.subscribe(subscriber);
                Toast.makeText(LockActivity.this, "Subscribed to topic: " + subscriber, Toast.LENGTH_SHORT).show();
                Log.d(TAG, "Subscribed to topic: " + subscriber);
            } catch (MqttException e) {
                e.printStackTrace();
                Toast.makeText(LockActivity.this, "Failed to subscribe to topic: " + subscriber, Toast.LENGTH_SHORT).show();
                Log.e(TAG, "Failed to subscribe to topic: " + subscriber, e);
            }
        } else {
            Toast.makeText(LockActivity.this, "MQTT not connected", Toast.LENGTH_SHORT).show();
            Log.e(TAG, "MQTT not connected");
        }
    }

    private void handleIncomingMessage(String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject json = new JSONObject(message);
                    int status = json.getInt("status");

                    // Display toast message
                    Toast.makeText(LockActivity.this, "Received message: " + status, Toast.LENGTH_SHORT).show();

                    // Update UI based on message
                    if (status == 0) {
                        doorOpen.setVisibility(View.VISIBLE);
                        doorClose.setVisibility(View.INVISIBLE);
                    } else if (status == 1) {
                        doorClose.setVisibility(View.VISIBLE);
                        doorOpen.setVisibility(View.INVISIBLE);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(LockActivity.this, "Failed to parse incoming message", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Failed to parse incoming message", e);
                }
            }
        });
    }
}
